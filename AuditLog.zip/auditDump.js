const mysqlConfig = require('./database/mysqldb')
const fs = require('fs');
const moment = require('moment');
const { exit } = require('process');
const targetDB = process.env.AL_DB_TARGET || 'auditlogs'
const fileDir = process.env.AL_OUTPUT_DIR || 'audit_logs'


class auditDump {
    constructor(props) {
        this.state = { 
            database: process.env.AL_DB_TARGET || 'auditlogs',
            table: process.env.AL_DB_TARGET_TABLE || 'event_history',
            fileDir: process.env.AL_OUTPUT_DIR || 'audit_logs'
        };
    }
    
   
   async dbManager(data, cb) {  
        const { field, database, table, interval, format  } = this.state;
        let qry = `INSERT INTO ${database}.${table} VALUES`
        let vals = '';
        
        data.forEach((doc, index) => {
            let objArr = [];
            Object.entries(doc).forEach(([key, value]) => {
                objArr.push(`"${value}"`);
                 // "a 5", "b 7", "c 9"
              });
                // console.log()
              vals = vals + `(${objArr.join(',')})${index == (data.length - 1) ? ';' : ','}`
            //   console.log(vals);
            })

            let sqlQuery = qry + vals;
                    mysqlConfig.query(sqlQuery, function (error, results, fields) {
                        console.log(error)
                        if (error) return cb(false);
                        else return cb && cb(true)
                    })

}   


    //Function to call to write in the file system the output json file result;
    readDir() {
        let { fileDir } = this.state;
        try {
            const files = fs.readdirSync(fileDir);
            if(files.length === 0) return exit();
            files.forEach(file => {
                let filePath = `${fileDir}/${file}`;
                if (fs.existsSync(filePath)) {
                   let data = fs.readFileSync(filePath, 'utf8')
                    this.dbManager(JSON.parse(data), a => {
                        // console.log(a)
                        if(a){
                            console.log('remove file')
                        }
                        // fs.unlinkSync(filePath)
                    })
                } else {
                    exit()
                }
            });
        } catch (err) {
            // console.log(err);
        }
    }
}


new auditDump().readDir();












